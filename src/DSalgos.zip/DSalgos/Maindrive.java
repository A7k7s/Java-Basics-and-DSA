package DSalgos;

public class Maindrive {

	public static void main(String[] args) {
		//code starts here
				SinglyLL nodes=new SinglyLL();
				nodes.begin(5);
				nodes.display();
				nodes.begin(4);
				nodes.display();
				nodes.begin(7);
				nodes.display();
				nodes.begin(6);
				nodes.display();
				nodes.end(8);
				nodes.display();
				nodes.delbegin();
				nodes.display();
				nodes.delend();
				nodes.display();
				nodes.middle(2, 2);
				nodes.display();
				nodes.delmiddle(3);
				nodes.display();
				nodes.search(5);
				
				
	}
}
