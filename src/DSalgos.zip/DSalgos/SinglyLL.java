package DSalgos;
public class SinglyLL {
	LinkedList head=null;
	void search(int data) {
		LinkedList current=head;
		int posi=1;
		while(current.data!=data) {
			current=current.address;
			posi++;
		}System.out.println(data+" present in position "+posi);
	}
	//insert at middle with position
	void delmiddle(int position) {
		LinkedList current=head;
		for(int i=1;i<position-1;i++) {
			current=current.address;
		}current.address=current.address.address;
	}
	void middle(int data,int position) {
		LinkedList newnode=new LinkedList(data);
		LinkedList current=head;
		for(int i=1;i<position-1;i++) {
			current=current.address;
		}newnode.address=current.address;
		current.address=newnode;
	}
	//insert at begin
	void begin(int data) {
		LinkedList newnode=new LinkedList(data);
		newnode.address=head;
		head=newnode;
	}
	//insert at end
	void end(int data) {
		LinkedList newnode=new LinkedList(data);
	    LinkedList current=head;
	    while(current.address!=null) {
	    	current=current.address;
	    }current.address=newnode;
	}
	//delete end
	void delend() {
		LinkedList current=head;
		while (current.address.address!=null) {
			current=current.address;
		}current.address=null;
	}
	//delete begin
	void delbegin() {
		LinkedList newnode=head.address;
		head=newnode;
	}
	//display
	void display() {
		LinkedList current=head;
		while(current.address!=null) {
			System.out.print(current.data+"->");
			current=current.address;
		}System.out.print(current.data);
		System.out.println();
	}
}
