package Algorithms;
import java.util.Scanner;
public class Array2dinput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		int col=sc.nextInt();
		int [][]arr=new int [row][col];
		for(int r=0;r<row;r++) {
			for (int c=0;c<col;c++) {
				arr[r][c]=sc.nextInt();
			}
		}
		for(int r=0;r<row;r++) {
			for (int c=0;c<col;c++) {
				System.out.print(arr[r][c]+" ");
			}
			System.out.println();
		}
		sc.close();

	}

}
